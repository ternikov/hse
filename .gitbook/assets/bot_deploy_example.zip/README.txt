EXAMPLE OF APP
--------------

CREATE THE APP IN HEROKU AND INSTALL IT (name for this example "bot-exmo")

PUT THE CODE IN FILE "bot-exmo.py"
CREATE THREE FILES (enclosed)

IN "requirements.txt" YOU CAN ADD VERSION NUMBERS FOR YOUR LIBRARIES

TO SHOW LIST OF LIBRARIES INSTALLED TYPE THE FOLLOWING IN TERMINAL (COMMAND LINE)
$ pip list

COMMANDS HEROKU (type step-by-step in terminal)
$ heroku login

THE PATH TO YOUR FOLDER WITH "bot-exmo.py"
$ cd "Documents/My bot/bot-exmo"

INITIALIZE AND UPLOAD ALL FILES TO SERVER
$ git init .
$ heroku git:remote -a bot-exmo

IF YOU WILL CHANGE SOMETHING IN CODE (OR FOLDER), RUN THE FOLLOWING EVERYTIME
$ git add .
$ git commit -am "make it better"
$ git push heroku master

START PROGRAM (RUN THE BOT) [in "Procfile" set "bot" as the name of instance]
$ heroku ps:scale bot=1

MONITOR ERRORS (CTRL+C for exit)
$ heroku logs --tail