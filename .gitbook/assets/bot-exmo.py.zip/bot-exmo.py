# CREATE THE BOT
token = 'YOUR_TOKEN'

# LOAD LIBRARIES
import telebot
import requests
import json
import pandas as pd
import time
import calendar

# BOT
bot = telebot.TeleBot(token)

# PARSE FUNCTION
def dataparse(date):
    enddate = int(time.mktime(time.strptime(date, '%Y-%m-%d')))
    startdate = int(time.mktime(time.strptime(date, '%Y-%m-%d')) - 3600 * 24 * 7)
    sitelink = 'https://chart.exmoney.com/ctrl/chart/history?symbol=BTC_USD&resolution=30&from={}&to={}'.format(startdate, enddate)
    r = requests.get(sitelink)
    f = json.loads(r.text)
    d = pd.DataFrame(f['candles'])

    average = round(d['c'].mean(), 2)
    start_val = round(d['c'][0], 2)
    end_val = round(d['c'][::-1].iloc[0], 2)

    start_time = time.strftime('%d %b %Y', time.strptime(time.ctime(startdate)))
    end_time = time.strftime('%d %b %Y', time.strptime(time.ctime(enddate)))

    if (start_val > average):
        a = '\U0001F53C{}: *{}*'.format(start_time, start_val)
    else:
        a = '\U0001F53B{}: *{}*'.format(start_time, start_val)

    if (end_val > average):
        b = '\U0001F53C{}: *{}*'.format(end_time, end_val)
    else:
        b = '\U0001F53B{}: *{}*'.format(end_time, end_val)

    c = '\nAverage: '+str(round(d['c'].mean(), 2))
    return [a, b, c]


# SAVE USER INFO
user_dict = {}

# HANDLE THE DATE
@bot.message_handler(commands = ['start'])
def myfunc(message):
    keyboard = telebot.types.ReplyKeyboardMarkup(one_time_keyboard=True, resize_keyboard=True) # create reply keyboard
    keyboard.row('2017', '2018', '2019', '2020')
    m = bot.send_message(message.chat.id, '*Choose year:*', 
                     reply_markup = keyboard, parse_mode = 'markdown')
    bot.register_next_step_handler(m, b)
    
def b(message):
    user_dict[message.chat.id] = [message.text, 0, 0]
    keyboard = telebot.types.ReplyKeyboardMarkup(one_time_keyboard=True) # create reply keyboard
    for i in range(3):
        keyboard.row(*map(str, range(i * 4 + 1, i * 4 + 5)))
    mm = bot.send_message(message.chat.id, '*Choose month:*', 
                     reply_markup = keyboard, parse_mode = 'markdown')
    bot.register_next_step_handler(mm, bb)

def bb(message):
    user_dict[message.chat.id][1] = message.text
    keyboard = telebot.types.ReplyKeyboardMarkup(one_time_keyboard=True) # create reply keyboard
    f = calendar.monthrange(int(user_dict[message.chat.id][0]), int(user_dict[message.chat.id][1]))[1]
    for i in range(4):
        keyboard.row(*map(str, range(i * 7 + 1, i * 7 + 8)))
    if f > 28:
        keyboard.row(*map(str, range(29, f + 1)))
    mmm = bot.send_message(message.chat.id, '*Choose day:*', 
                     reply_markup = keyboard, parse_mode = 'markdown')
    bot.register_next_step_handler(mmm, bbb)

def bbb(message):
    bot.send_chat_action(message.chat.id, 'typing')
    user_dict[message.chat.id][2] = message.text
    year = user_dict[message.chat.id][0]
    month = user_dict[message.chat.id][1]
    day = user_dict[message.chat.id][2]
    date1 = time.strftime('%Y-%m-%d', time.strptime('-'.join([year, month, day]), '%Y-%m-%d'))
    d = dataparse(date1)
    mmmm = bot.send_message(message.chat.id, '*BTC/USD*\n\n'+'\n'.join(d), parse_mode = 'markdown')

# Non-stop mode
if __name__ == '__main__':
    bot.polling(none_stop=True)